#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <arpa/inet.h>

#define MAX_CITIES 100
#define MAX_CITY_NAME 50
#define MAX_WEATHER_DESC 100
#define BUFFER_SIZE 256
#define HISTORY_FILE "history.log"
#define DATA_FILE "weather_data.txt"

typedef struct {
    char city[MAX_CITY_NAME];
    char weather[MAX_WEATHER_DESC];
} WeatherData;

WeatherData weather_data[MAX_CITIES];
int entry_count = 0;
pthread_mutex_t data_mutex;

void load_data_from_file(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("File not found. Creating a new file...\n");
        return;
    }

    pthread_mutex_lock(&data_mutex);
    while (fscanf(file, "%49s %99[^\n]", weather_data[entry_count].city, weather_data[entry_count].weather) == 2) {
        entry_count++;
        if (entry_count >= MAX_CITIES) break;
    }
    fclose(file);
    pthread_mutex_unlock(&data_mutex);
}

void save_data_to_file(const char *filename) {
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        printf("Failed to save data to file.\n");
        return;
    }

    pthread_mutex_lock(&data_mutex);
    for (int i = 0; i < entry_count; i++) {
        fprintf(file, "%s %s\n", weather_data[i].city, weather_data[i].weather);
    }
    fclose(file);
    pthread_mutex_unlock(&data_mutex);
}

void log_history(const char *entry) {
    FILE *file = fopen(HISTORY_FILE, "a");
    if (file == NULL) {
        printf("Failed to log history.\n");
        return;
    }

    fprintf(file, "%s\n", entry);
    fclose(file);
}

void handle_client(int client_sock, struct sockaddr_in client_addr) {
    char buffer[BUFFER_SIZE], response[BUFFER_SIZE];
    char command[10], city[MAX_CITY_NAME], weather[MAX_WEATHER_DESC];

    printf("Client connected: %s:%d\n", inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));

    while (1) {
        memset(buffer, 0, BUFFER_SIZE);
        if (recv(client_sock, buffer, BUFFER_SIZE, 0) <= 0) break;

        sscanf(buffer, "%s %49s %[^\n]", command, city, weather);
        memset(response, 0, BUFFER_SIZE);

        if (strcmp(command, "GET") == 0) {
            pthread_mutex_lock(&data_mutex);
            int found = 0;
            for (int i = 0; i < entry_count; i++) {
                if (strcmp(weather_data[i].city, city) == 0) {
                    snprintf(response, BUFFER_SIZE, "Weather in %s: %s", city, weather_data[i].weather);
                    found = 1;
                    break;
                }
            }
            pthread_mutex_unlock(&data_mutex);

            if (!found) {
                snprintf(response, BUFFER_SIZE, "City %s not found.", city);
            }

            log_history(buffer);
        } else if (strcmp(command, "SET") == 0) {
            pthread_mutex_lock(&data_mutex);
            int updated = 0;
            for (int i = 0; i < entry_count; i++) {
                if (strcmp(weather_data[i].city, city) == 0) {
                    strcpy(weather_data[i].weather, weather);
                    updated = 1;
                    break;
                }
            }

            if (!updated && entry_count < MAX_CITIES) {
                strcpy(weather_data[entry_count].city, city);
                strcpy(weather_data[entry_count].weather, weather);
                entry_count++;
            }
            pthread_mutex_unlock(&data_mutex);

            save_data_to_file(DATA_FILE);

            snprintf(response, BUFFER_SIZE, "Weather for %s updated to: %s", city, weather);
            log_history(buffer);

            printf("Modification: %s\n", buffer); // Log modification
        } else {
            snprintf(response, BUFFER_SIZE, "Invalid command.");
        }

        send(client_sock, response, strlen(response), 0);
    }

    printf("Client disconnected: %s:%d\n", inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));
    close(client_sock);
    pthread_exit(NULL);
}

void *client_thread(void *arg) {
    int client_sock = ((int *)arg)[0];
    struct sockaddr_in client_addr = *((struct sockaddr_in *)((int *)arg + 1));
    free(arg);
    handle_client(client_sock, client_addr);
    return NULL;
}

int main() {
    int server_sock, *client_sock;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_addr_len = sizeof(client_addr);
    int port;

    printf("Enter the port number for the server: ");
    scanf("%d", &port);

    pthread_mutex_init(&data_mutex, NULL);
    load_data_from_file(DATA_FILE);

    server_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (server_sock == -1) {
        perror("Socket creation failed");
        return 1;
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(port);

    if (bind(server_sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) == -1) {
        perror("Binding failed");
        return 1;
    }

    if (listen(server_sock, 5) == -1) {
        perror("Listening failed");
        return 1;
    }

    printf("Server is running on port %d...\n", port);

    while (1) {
        int *args = malloc(sizeof(int) + sizeof(struct sockaddr_in));
        client_sock = args;
        *client_sock = accept(server_sock, (struct sockaddr *)&client_addr, &client_addr_len);
        if (*client_sock == -1) {
            perror("Accept failed");
            free(args);
            continue;
        }

        memcpy(args + 1, &client_addr, sizeof(client_addr));

        pthread_t tid;
        pthread_create(&tid, NULL, client_thread, args);
        pthread_detach(tid);
    }

    pthread_mutex_destroy(&data_mutex);
    close(server_sock);
    return 0;
}
